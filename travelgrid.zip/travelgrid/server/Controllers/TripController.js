const Trip = require("../models/Trip");


// ========================================
// CREATE TRIP BOOKING REQUEST
// ========================================

const createTrip = async (req, res) => {

    try {

        const {
            from,
            destination,
            travelMode,
            travelDate,
            returnDate,
            passengers,
            tripType,
            hotelRequired,
            rooms,
            mobile,
            places
        } = req.body;


        // ========================================
        // REQUIRED FIELD VALIDATION
        // ========================================

        if (
            !from ||
            !destination ||
            !travelMode ||
            !travelDate ||
            !returnDate ||
            !passengers ||
            !mobile
        ) {

            return res.status(400).json({
                success: false,
                message: "Please fill all trip details."
            });

        }


        // ========================================
        // DATE VALIDATION
        // ========================================

        if (
            new Date(returnDate) <
            new Date(travelDate)
        ) {

            return res.status(400).json({
                success: false,
                message: "Return date cannot be before travel date."
            });

        }


        // ========================================
        // MOBILE VALIDATION
        // ========================================

        if (!/^[0-9]{10}$/.test(mobile)) {

            return res.status(400).json({
                success: false,
                message: "Please enter a valid 10 digit mobile number."
            });

        }


        // ========================================
        // BOOKING REFERENCE
        // ========================================

        const bookingReference =
            "TGTRIP" + Date.now();


        // ========================================
        // CREATE TRIP
        // ========================================

        const trip = new Trip({

            userId: req.user.id,

            from: from,

            destination: destination,

            travelMode: travelMode,

            travelDate: travelDate,

            returnDate: returnDate,

            passengers: Number(passengers),

            tripType: tripType || "Family",

            hotelRequired:
                hotelRequired || "No",

            rooms:
                Number(rooms) || 1,

            mobile: mobile,

            places:
                Array.isArray(places)
                    ? places
                    : [],

            status: "Pending",

            bookingReference:
                bookingReference
        });


        // ========================================
        // SAVE TO MONGODB
        // ========================================

        await trip.save();


        // ========================================
        // SUCCESS RESPONSE
        // ========================================

        return res.status(201).json({

            success: true,

            message:
                "Trip booking request submitted successfully.",

            bookingReference:
                bookingReference,

            trip: trip

        });

    }


    catch (error) {

        console.error(
            "Trip Booking Error:",
            error
        );

        return res.status(500).json({

            success: false,

            message:
                "Failed to submit trip booking request.",

            error:
                error.message

        });

    }

};


// ========================================
// GET MY TRIP REQUESTS
// ========================================

const getMyTrips = async (req, res) => {

    try {

        const trips =
            await Trip.find({
                userId: req.user.id
            }).sort({
                createdAt: -1
            });


        return res.json({

            success: true,

            trips: trips

        });

    }


    catch (error) {

        console.error(
            "Get Trips Error:",
            error
        );

        return res.status(500).json({

            success: false,

            message:
                "Failed to fetch trip requests."

        });

    }

};


module.exports = {

    createTrip,
    getMyTrips

};