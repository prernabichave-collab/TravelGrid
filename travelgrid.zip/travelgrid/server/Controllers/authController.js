const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");


/* ================= REGISTER ================= */

exports.registerUser = async (req, res) => {
    try {
        const {
            fullname,
            email,
            mobile,
            password
        } = req.body;

        if (!fullname || !email || !mobile || !password) {
            return res.status(400).json({
                message: "Please fill all required fields"
            });
        }

        const existingUser = await User.findOne({ email });

        if (existingUser) {
            const hashedPassword = await bcrypt.hash(password, 10);

            existingUser.fullname = fullname;
            existingUser.mobile = mobile;
            existingUser.password = hashedPassword;

            await existingUser.save();

            const token = jwt.sign(
                { id: existingUser._id },
                process.env.JWT_SECRET,
                { expiresIn: "7d" }
            );

            return res.status(200).json({
                message: "Account updated successfully",
                token,
                user: {
                    id: existingUser._id,
                    fullname: existingUser.fullname,
                    email: existingUser.email,
                    mobile: existingUser.mobile
                }
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            fullname,
            email,
            mobile,
            password: hashedPassword
        });

        await newUser.save();

        const token = jwt.sign(
            { id: newUser._id },
            process.env.JWT_SECRET,
            { expiresIn: "7d" }
        );

        res.status(201).json({
            message: "Registration Successful",
            token,
            user: {
                id: newUser._id,
                fullname: newUser.fullname,
                email: newUser.email,
                mobile: newUser.mobile
            }
        });

    } catch (error) {
        console.log("Registration Error:", error);

        res.status(500).json({
            message: "Registration Failed",
            error: error.message
        });
    }
};


/* ================= LOGIN ================= */

exports.loginUser = async (req, res) => {
    try {
        const {
            email,
            password
        } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: "Email and password are required"
            });
        }

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: "User Not Found"
            });
        }

        const match = await bcrypt.compare(
            password,
            user.password
        );

        if (!match) {
            return res.status(401).json({
                message: "Incorrect Password"
            });
        }

        const token = jwt.sign(
            { id: user._id },
            process.env.JWT_SECRET,
            { expiresIn: "7d" }
        );

        res.status(200).json({
            message: "Login Successful",
            token,
            user: {
                id: user._id,
                fullname: user.fullname,
                email: user.email,
                mobile: user.mobile
            }
        });

    } catch (error) {
        console.log("Login Error:", error);

        res.status(500).json({
            message: "Login Failed",
            error: error.message
        });
    }
};


/* ================= PROFILE ================= */

exports.getProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user.id)
            .select("fullname email mobile");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.status(200).json({
            message: "Profile fetched successfully",
            user: {
                id: user._id,
                fullname: user.fullname,
                email: user.email,
                mobile: user.mobile
            }
        });

    } catch (error) {
        console.log("Profile Error:", error);

        res.status(500).json({
            message: "Failed to fetch profile"
        });
    }
};


/* ================= UPDATE PROFILE ================= */

exports.updateProfile = async (req, res) => {
    try {
        const { fullname } = req.body;

        if (!fullname || !fullname.trim()) {
            return res.status(400).json({
                message: "Full name is required"
            });
        }

        const user = await User.findByIdAndUpdate(
            req.user.id,
            {
                fullname: fullname.trim()
            },
            {
                new: true,
                runValidators: true
            }
        ).select("-password");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.status(200).json({
            message: "Name saved successfully",
            user: {
                id: user._id,
                fullname: user.fullname,
                email: user.email,
                mobile: user.mobile
            }
        });

    } catch (error) {
        console.log("Update Profile Error:", error);

        res.status(500).json({
            message: "Failed to save name"
        });
    }
};


/* ================= FORGOT PASSWORD ================= */

exports.forgotPassword = async (req, res) => {
    try {
        const { email } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: "Email not registered"
            });
        }

        const otp = Math.floor(
            100000 + Math.random() * 900000
        ).toString();

        user.resetOTP = otp;
        user.resetOTPExpiry =
            Date.now() + 10 * 60 * 1000;

        await user.save();

        console.log("OTP for", email, "is:", otp);

        res.status(200).json({
            message: "OTP generated successfully",
            otp
        });

    } catch (error) {
        console.log("Forgot Password Error:", error);

        res.status(500).json({
            message: "Forgot password failed"
        });
    }
};


/* ================= VERIFY OTP ================= */

exports.verifyOTP = async (req, res) => {
    try {
        const {
            email,
            otp
        } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        if (
            !user.resetOTP ||
            String(user.resetOTP) !== String(otp)
        ) {
            return res.status(400).json({
                message: "Invalid OTP"
            });
        }

        if (user.resetOTPExpiry < Date.now()) {
            return res.status(400).json({
                message: "OTP expired"
            });
        }

        res.status(200).json({
            message: "OTP verified successfully"
        });

    } catch (error) {
        console.log("Verify OTP Error:", error);

        res.status(500).json({
            message: "OTP verification failed"
        });
    }
};


/* ================= RESET PASSWORD ================= */

exports.resetPassword = async (req, res) => {
    try {
        const {
            email,
            otp,
            newPassword
        } = req.body;

        if (!email || !otp || !newPassword) {
            return res.status(400).json({
                message: "Email, OTP and new password are required"
            });
        }

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        if (
            !user.resetOTP ||
            String(user.resetOTP) !== String(otp)
        ) {
            return res.status(400).json({
                message: "Invalid OTP"
            });
        }

        if (user.resetOTPExpiry < Date.now()) {
            return res.status(400).json({
                message: "OTP expired"
            });
        }

        const hashedPassword = await bcrypt.hash(
            newPassword,
            10
        );

        user.password = hashedPassword;
        user.resetOTP = undefined;
        user.resetOTPExpiry = undefined;

        await user.save();

        res.status(200).json({
            message: "Password reset successfully"
        });

    } catch (error) {
        console.log("Reset Password Error:", error);

        res.status(500).json({
            message: "Password reset failed"
        });
    }
};


/* ================= CHANGE PASSWORD ================= */

exports.changePassword = async (req, res) => {
    try {
        const {
            oldPassword,
            newPassword
        } = req.body;

        if (!oldPassword || !newPassword) {
            return res.status(400).json({
                message: "Old and new password are required"
            });
        }

        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const match = await bcrypt.compare(
            oldPassword,
            user.password
        );

        if (!match) {
            return res.status(400).json({
                message: "Old password is incorrect"
            });
        }

        const hashedPassword = await bcrypt.hash(
            newPassword,
            10
        );

        user.password = hashedPassword;

        await user.save();

        res.status(200).json({
            message: "Password changed successfully"
        });

    } catch (error) {
        console.log("Change Password Error:", error);

        res.status(500).json({
            message: "Change password failed"
        });
    }
};
