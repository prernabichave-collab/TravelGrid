const Booking = require("../models/booking");


// ===============================
// CREATE HOTEL BOOKING
// ===============================

const createBooking = async (req, res) => {

    try {

        const {
            hotelName,
            city,
            place,
            checkIn,
            checkOut,
            guests,
            rooms,
            price
        } = req.body;


        // Required fields check
        if (
            !hotelName ||
            !city ||
            !place ||
            !checkIn ||
            !checkOut ||
            !guests ||
            !rooms
        ) {

            return res.status(400).json({
                message: "Please fill all booking details."
            });

        }


        // Date validation
        if (
            new Date(checkOut) <=
            new Date(checkIn)
        ) {

            return res.status(400).json({
                message: "Check-out date must be after check-in date."
            });

        }


        // Generate booking reference
        const bookingReference =
            "TG" +
            Date.now();


        // Create booking
        const booking =
            new Booking({

                userId:
                    req.user.id,

                hotelName:
                    hotelName,

                city:
                    city,

                place:
                    place,

                checkIn:
                    checkIn,

                checkOut:
                    checkOut,

                guests:
                    Number(guests),

                rooms:
                    Number(rooms),

                price:
                    Number(price) || 0,

                bookingReference:
                    bookingReference,

                status:
                    "CONFIRMED"

            });


        // Save booking
        await booking.save();


        // Success response
        res.status(201).json({

            message:
                "Hotel booking created successfully.",

            booking:
                booking

        });

    }


    catch (error) {

        console.error(
            "Booking Error:",
            error
        );


        res.status(500).json({

            message:
                "Failed to create booking.",

            error:
                error.message

        });

    }

};


// ===============================
// GET MY BOOKINGS
// ===============================

const getMyBookings = async (req, res) => {

    try {

        const bookings =
            await Booking.find({

                userId:
                    req.user.id

            }).sort({

                createdAt:
                    -1

            });


        res.json({

            bookings:
                bookings

        });

    }


    catch (error) {

        console.error(
            "Get Bookings Error:",
            error
        );


        res.status(500).json({

            message:
                "Failed to fetch bookings."

        });

    }

};


module.exports = {

    createBooking,
    getMyBookings

};