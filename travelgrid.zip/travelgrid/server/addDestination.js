require("dotenv").config();
const mongoose = require("mongoose");
const Destination = require("./models/Destination");

const MONGO_URI = process.env.MONGO_URI;

async function addDestination() {

    try {

        await mongoose.connect(MONGO_URI);

        console.log("MongoDB Connected");

        const destination = await Destination.create({

            name: "Mahabaleshwar",

            city: "Mahabaleshwar",

            district: "Satara",

            state: "Maharashtra",

            description:
                "Mahabaleshwar is a popular hill station in the Western Ghats of Maharashtra known for viewpoints, lakes, waterfalls, greenery and historical attractions.",

            latitude: 17.9307,

            longitude: 73.6477,

            attractions: [

                {
                    name: "Venna Lake",
                    description: "Popular lake known for boating and scenic surroundings."
                },

                {
                    name: "Arthur's Seat",
                    description: "Famous viewpoint offering views of valleys and mountains."
                },

                {
                    name: "Pratapgad Fort",
                    description: "Historic fort located near Mahabaleshwar."
                },

                {
                    name: "Mapro Garden",
                    description: "Popular attraction known for strawberries and food products."
                },

                {
                    name: "Wilson Point",
                    description: "Popular sunrise viewpoint and one of the highest points in Mahabaleshwar."
                },

                {
                    name: "Lingmala Waterfall",
                    description: "Popular waterfall surrounded by greenery."
                }

            ],

            nearestRailwayStations: [

                {
                    name: "Wathar Railway Station",
                    distanceKm: 60
                },

                {
                    name: "Satara Railway Station",
                    distanceKm: 61
                },

                {
                    name: "Pune Railway Station",
                    distanceKm: 124
                }

            ],

            nearestAirports: [

                {
                    name: "Pune International Airport",
                    distanceKm: 130
                },

                {
                    name: "Chhatrapati Shivaji Maharaj International Airport, Mumbai",
                    distanceKm: 271
                }

            ],

            bestTimeToVisit:
                "October to February for pleasant weather; monsoon is popular for greenery and waterfalls."

        });

        console.log("Destination Added:");
        console.log(destination);

        process.exit();

    } catch (error) {

        console.error("Error:", error);

        process.exit(1);

    }

}

addDestination();