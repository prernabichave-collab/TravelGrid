const mongoose = require("mongoose");
require("dotenv").config();

const Destination = require("./models/Destination");

const destinations = [
    {
        name: "Lonavala",
        city: "Lonavala",
        district: "Pune",
        state: "Maharashtra",
        description: "Lonavala is a beautiful hill station famous for waterfalls, forts, lakes and scenic viewpoints.",
        latitude: 18.7546,
        longitude: 73.4062,
        bestTimeToVisit: "June to February",

        attractions: [
            {
                name: "Bhushi Dam",
                description: "A popular monsoon destination surrounded by hills.",
                image: "https://images.unsplash.com/photo-1598091383021-15ddea10925d"
            },
            {
                name: "Tiger Point",
                description: "A famous viewpoint offering beautiful valley views.",
                image: "https://images.unsplash.com/photo-1500534623283-312aade485b7"
            },
            {
                name: "Rajmachi Fort",
                description: "Historic fort surrounded by the Sahyadri mountains.",
                image: "https://images.unsplash.com/photo-1596402184320-417e7178b2cd"
            }
        ],

        nearestRailwayStations: [
            {
                name: "Lonavala Railway Station",
                distanceKm: 2
            }
        ],

        nearestAirports: [
            {
                name: "Pune International Airport",
                distanceKm: 65
            }
        ]
    },

    {
        name: "Mahabaleshwar",
        city: "Mahabaleshwar",
        district: "Satara",
        state: "Maharashtra",
        description: "Mahabaleshwar is a popular hill station known for viewpoints, waterfalls, strawberries and pleasant weather.",
        latitude: 17.9307,
        longitude: 73.6477,
        bestTimeToVisit: "October to June",

        attractions: [
            {
                name: "Arthur's Seat",
                description: "One of the most famous viewpoints in Mahabaleshwar.",
                image: "https://images.unsplash.com/photo-1500534623283-312aade485b7"
            },
            {
                name: "Venna Lake",
                description: "A beautiful lake popular for boating and sightseeing.",
                image: "https://images.unsplash.com/photo-1500534623283-312aade485b7"
            },
            {
                name: "Pratapgad Fort",
                description: "A historic fort located near Mahabaleshwar.",
                image: "https://images.unsplash.com/photo-1596402184320-417e7178b2cd"
            }
        ],

        nearestRailwayStations: [
            {
                name: "Satara Railway Station",
                distanceKm: 60
            }
        ],

        nearestAirports: [
            {
                name: "Pune International Airport",
                distanceKm: 120
            }
        ]
    },

    {
        name: "Matheran",
        city: "Matheran",
        district: "Raigad",
        state: "Maharashtra",
        description: "Matheran is a peaceful hill station famous for viewpoints, forests and its vehicle-free environment.",
        latitude: 18.9869,
        longitude: 73.2711,
        bestTimeToVisit: "October to May",

        attractions: [
            {
                name: "Panorama Point",
                description: "A scenic viewpoint offering panoramic mountain views.",
                image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b"
            },
            {
                name: "Echo Point",
                description: "A popular viewpoint surrounded by beautiful hills.",
                image: "https://images.unsplash.com/photo-1500534623283-312aade485b7"
            },
            {
                name: "Charlotte Lake",
                description: "A peaceful lake surrounded by greenery.",
                image: "https://images.unsplash.com/photo-1500534623283-312aade485b7"
            }
        ],

        nearestRailwayStations: [
            {
                name: "Neral Railway Station",
                distanceKm: 21
            }
        ],

        nearestAirports: [
            {
                name: "Chhatrapati Shivaji Maharaj International Airport",
                distanceKm: 90
            }
        ]
    },

    {
        name: "Alibaug",
        city: "Alibaug",
        district: "Raigad",
        state: "Maharashtra",
        description: "Alibaug is a coastal destination famous for beaches, forts and sea views.",
        latitude: 18.6414,
        longitude: 72.8722,
        bestTimeToVisit: "November to February",

        attractions: [
            {
                name: "Alibaug Beach",
                description: "A popular beach with beautiful Arabian Sea views.",
                image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e"
            },
            {
                name: "Kolaba Fort",
                description: "A historic sea fort located near Alibaug beach.",
                image: "https://images.unsplash.com/photo-1596402184320-417e7178b2cd"
            },
            {
                name: "Kashid Beach",
                description: "A scenic beach known for clean sand and blue water.",
                image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e"
            }
        ],

        nearestRailwayStations: [
            {
                name: "Pen Railway Station",
                distanceKm: 30
            }
        ],

        nearestAirports: [
            {
                name: "Chhatrapati Shivaji Maharaj International Airport",
                distanceKm: 105
            }
        ]
    },

    {
        name: "Nashik",
        city: "Nashik",
        district: "Nashik",
        state: "Maharashtra",
        description: "Nashik is a historic city famous for temples, vineyards, the Godavari River and Trimbakeshwar.",
        latitude: 19.9975,
        longitude: 73.7898,
        bestTimeToVisit: "October to March",

        attractions: [
            {
                name: "Trimbakeshwar Temple",
                description: "One of the important Jyotirlinga temples of India.",
                image: "https://images.unsplash.com/photo-1564507592333-c60657eea523"
            },
            {
                name: "Sula Vineyards",
                description: "A famous vineyard and tourist attraction near Nashik.",
                image: "https://images.unsplash.com/photo-1473973266408-ed4e27abdd47"
            },
            {
                name: "Pandavleni Caves",
                description: "Ancient rock-cut caves located near Nashik.",
                image: "https://images.unsplash.com/photo-1596402184320-417e7178b2cd"
            }
        ],

        nearestRailwayStations: [
            {
                name: "Nashik Road Railway Station",
                distanceKm: 9
            }
        ],

        nearestAirports: [
            {
                name: "Nashik Airport",
                distanceKm: 20
            }
        ]
    }
];


async function seedDatabase() {

    try {

        await mongoose.connect(process.env.MONGO_URI);

        console.log("✅ MongoDB Connected");

        await Destination.deleteMany();

        await Destination.insertMany(destinations);

        console.log("✅ Destinations inserted successfully");

        process.exit();

    } catch (error) {

        console.error("❌ Seed Error:", error);

        process.exit(1);

    }
}


seedDatabase();