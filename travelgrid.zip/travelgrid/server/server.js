const express = require("express");
const cors = require("cors");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config();

const mysqlDB = require("./config/mysql");
const connectMongoDB = require("./config/mongodb");

const authRoutes = require("./routes/authRoutes");
const destinationRoutes = require("./routes/destinationRoutes");
const travelRoutes = require("./routes/travelRoutes");
const bookingRoutes = require("./Routes/bookingRoutes.js");
const tripRoutes = require("./Routes/TripRoutes");
const locationRoutes = require("./routes/locationRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
    express.static(
        path.join(__dirname, "../client")
    )
);

mysqlDB;
connectMongoDB();

console.log("✅ Auth Router Loaded");

app.use("/api/auth", (req, res, next) => {
    console.log(
        "Auth Route Hit:",
        req.method,
        req.url
    );
    next();
});

app.use("/api/auth", authRoutes);
app.use("/api/destinations", destinationRoutes);
app.use("/api/travel", travelRoutes);
app.use("/api/locations", locationRoutes);
app.use("/api/booking", bookingRoutes);
app.use("/api/trips", tripRoutes);

app.get("/test", (req, res) => {
    res.status(200).send(
        "Server Test OK"
    );
});



app.get("/", (req, res) => {
    res.status(200).send(
        "TravelGrid Backend Running..."
    );
});


app.get("/hotels.html", (req, res) => {
    res.sendFile(
        path.join(
            __dirname,
            "../client/hotels.html"
        )
    );
});

app.get("/booking.html", (req, res) => {
    res.sendFile(
        path.join(
            __dirname,
            "../client/booking.html"
        )
    );
});



const PORT =
    process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(
        `Server running on http://localhost:${PORT}`
    );
});